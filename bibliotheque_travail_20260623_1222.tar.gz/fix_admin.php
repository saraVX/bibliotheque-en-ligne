<?php
require_once 'config.php';

// 1. Vérifier si admin existe déjà
$check = $db->prepare("SELECT * FROM utilisateurs WHERE email = ?");
$check->execute(['admin@bibliotheque.com']);
$admin = $check->fetch();

if($admin) {
    // Mettre à jour le rôle
    $update = $db->prepare("UPDATE utilisateurs SET role = 'admin' WHERE email = ?");
    $update->execute(['admin@bibliotheque.com']);
    echo "✅ Admin existant - rôle mis à jour en 'admin'\n";
} else {
    // Créer un nouvel admin
    $password = password_hash('admin123', PASSWORD_DEFAULT);
    $insert = $db->prepare("INSERT INTO utilisateurs (nom, email, password, role) VALUES (?, ?, ?, ?)");
    $insert->execute(['Administrateur', 'admin@bibliotheque.com', $password, 'admin']);
    echo "✅ Nouvel admin créé\n";
}

// Vérifier le résultat
$verify = $db->prepare("SELECT * FROM utilisateurs WHERE email = ?");
$verify->execute(['admin@bibliotheque.com']);
$user = $verify->fetch();

echo "\n--- VÉRIFICATION ---\n";
echo "Nom: " . $user['nom'] . "\n";
echo "Email: " . $user['email'] . "\n";
echo "Rôle: " . $user['role'] . "\n";

if($user['role'] == 'admin') {
    echo "✅ L'utilisateur est bien ADMIN !\n";
    echo "Email: admin@bibliotheque.com\n";
    echo "Mot de passe: admin123\n";
} else {
    echo "❌ Le rôle n'est pas admin !\n";
}
?>
