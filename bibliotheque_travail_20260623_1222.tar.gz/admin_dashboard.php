<?php
session_start();
require_once 'config.php';
require_once 'check_admin.php';
requireAdmin();

// Statistiques
$total_livres = $db->query("SELECT COUNT(*) FROM livres")->fetchColumn();
$total_users = $db->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'user'")->fetchColumn();
$total_commandes = $db->query("SELECT COUNT(*) FROM commandes")->fetchColumn();
$stock_total = $db->query("SELECT SUM(stock) FROM livres")->fetchColumn();

// Récupérer les 3 dernières commandes
$dernieres_commandes = $db->query("
    SELECT c.*, u.nom, u.email 
    FROM commandes c
    JOIN utilisateurs u ON c.user_id = u.id
    ORDER BY c.date_commande DESC
    LIMIT 3
")->fetchAll();

// STATISTIQUES PAR MOIS ET PAR AN
$commandes_par_mois = $db->query("
    SELECT 
        strftime('%Y-%m', date_commande) as mois,
        COUNT(*) as nombre_commandes,
        SUM(total) as chiffre_affaires
    FROM commandes
    GROUP BY strftime('%Y-%m', date_commande)
    ORDER BY mois DESC
    LIMIT 12
")->fetchAll();

$commandes_par_an = $db->query("
    SELECT 
        strftime('%Y', date_commande) as annee,
        COUNT(*) as nombre_commandes,
        SUM(total) as chiffre_affaires
    FROM commandes
    GROUP BY strftime('%Y', date_commande)
    ORDER BY annee DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f7fafc;
        }
        .header {
            background: #2d3748;
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            font-size: 1.5rem;
        }
        .header a {
            color: white;
            text-decoration: none;
            margin-left: 1rem;
            padding: 0.5rem 1rem;
            border-radius: 5px;
        }
        .header a:hover {
            background: #4a5568;
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            color: #718096;
            font-size: 0.9rem;
            text-transform: uppercase;
            margin-bottom: 0.5rem;
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: #2d3748;
        }
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }
        .menu-item {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            text-decoration: none;
            color: #2d3748;
            transition: all 0.3s;
            border: 1px solid #e2e8f0;
            display: block;
        }
        .menu-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-color: #667eea;
        }
        .menu-item h3 {
            margin-bottom: 0.5rem;
            color: #667eea;
        }
        .menu-item p {
            color: #718096;
        }

        /* BOX DERNIERES COMMANDES */
        .dernieres-commandes-box {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-top: 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
        }
        .dernieres-commandes-box h2 {
            color: #2d3748;
            margin-bottom: 1rem;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .dernieres-commandes-box table {
            width: 100%;
            border-collapse: collapse;
        }
        .dernieres-commandes-box th {
            text-align: left;
            padding: 0.75rem;
            background: #f8fafc;
            color: #4a5568;
            font-weight: 500;
            border-bottom: 2px solid #e2e8f0;
        }
        .dernieres-commandes-box td {
            padding: 0.75rem;
            border-bottom: 1px solid #e2e8f0;
            color: #4a5568;
        }
        .dernieres-commandes-box .statut-badge {
            display: inline-block;
            padding: 0.2rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        .statut-en_attente { background: #fed7d7; color: #742a2a; }
        .statut-confirmee { background: #c6f6d5; color: #22543d; }
        .statut-expediee { background: #bee3f8; color: #1e4a6b; }
        .statut-livree { background: #fefcbf; color: #744210; }
        .btn-voir-toutes {
            display: inline-block;
            margin-top: 1rem;
            padding: 0.5rem 1.5rem;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        .btn-voir-toutes:hover {
            background: #5a67d8;
        }
        .aucune-commande {
            text-align: center;
            padding: 2rem;
            color: #a0aec0;
        }
        .total-commande {
            font-weight: 600;
            color: #48bb78;
        }

        /* STATS COMMANDES PAR MOIS/AN */
        .stats-commandes-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-top: 2rem;
        }
        .stats-commandes-box {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-left: 4px solid #48bb78;
        }
        .stats-commandes-box h2 {
            color: #2d3748;
            margin-bottom: 1rem;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .stats-commandes-box table {
            width: 100%;
            border-collapse: collapse;
        }
        .stats-commandes-box th {
            text-align: left;
            padding: 0.5rem;
            background: #f8fafc;
            color: #4a5568;
            font-weight: 500;
            border-bottom: 1px solid #e2e8f0;
        }
        .stats-commandes-box td {
            padding: 0.5rem;
            border-bottom: 1px solid #e2e8f0;
        }
        .chiffre-affaires {
            font-weight: 600;
            color: #48bb78;
        }
        .total-ligne {
            background: #f8fafc;
            font-weight: 600;
        }
        .total-ligne td {
            border-top: 2px solid #e2e8f0;
            padding-top: 0.5rem;
        }
        @media (max-width: 768px) {
            .stats-commandes-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>📚 Administration - Bibliothèque</h1>
        <div>
            <span>👤 <?= htmlspecialchars($_SESSION['user_nom']) ?> (Admin)</span>
            <a href="index.php">Voir le site</a>
            <a href="deconnexion.php">Déconnexion</a>
        </div>
    </div>

    <div class="container">
        <!-- STATISTIQUES -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Livres</h3>
                <div class="stat-number"><?= $total_livres ?></div>
            </div>
            <div class="stat-card">
                <h3>Stock total</h3>
                <div class="stat-number"><?= $stock_total ?></div>
            </div>
            <div class="stat-card">
                <h3>Utilisateurs</h3>
                <div class="stat-number"><?= $total_users ?></div>
            </div>
            <div class="stat-card">
                <h3>Commandes</h3>
                <div class="stat-number"><?= $total_commandes ?></div>
            </div>
        </div>

        <!-- STATISTIQUES PAR MOIS ET PAR AN -->
        <div class="stats-commandes-grid">
            <!-- PAR MOIS -->
            <div class="stats-commandes-box">
                <h2>📊 Commandes par mois (12 derniers mois)</h2>
                <?php if(empty($commandes_par_mois)): ?>
                    <p style="color: #a0aec0; text-align: center; padding: 1rem;">Aucune commande</p>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Mois</th>
                                <th>Nb commandes</th>
                                <th>CA</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $total_ca_mois = 0;
                            $total_nb_mois = 0;
                            foreach($commandes_par_mois as $mois):
                                $total_ca_mois += $mois['chiffre_affaires'];
                                $total_nb_mois += $mois['nombre_commandes'];
                            ?>
                            <tr>
                                <td><?= $mois['mois'] ?></td>
                                <td><?= $mois['nombre_commandes'] ?></td>
                                <td class="chiffre-affaires"><?= number_format($mois['chiffre_affaires'], 2) ?> €</td>
                            </tr>
                            <?php endforeach; ?>
                            <tr class="total-ligne">
                                <td><strong>TOTAL</strong></td>
                                <td><strong><?= $total_nb_mois ?></strong></td>
                                <td><strong><?= number_format($total_ca_mois, 2) ?> €</strong></td>
                            </tr>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- PAR AN -->
            <div class="stats-commandes-box">
                <h2>📊 Commandes par année</h2>
                <?php if(empty($commandes_par_an)): ?>
                    <p style="color: #a0aec0; text-align: center; padding: 1rem;">Aucune commande</p>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Année</th>
                                <th>Nb commandes</th>
                                <th>CA</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $total_ca_an = 0;
                            $total_nb_an = 0;
                            foreach($commandes_par_an as $an):
                                $total_ca_an += $an['chiffre_affaires'];
                                $total_nb_an += $an['nombre_commandes'];
                            ?>
                            <tr>
                                <td><?= $an['annee'] ?></td>
                                <td><?= $an['nombre_commandes'] ?></td>
                                <td class="chiffre-affaires"><?= number_format($an['chiffre_affaires'], 2) ?> €</td>
                            </tr>
                            <?php endforeach; ?>
                            <tr class="total-ligne">
                                <td><strong>TOTAL</strong></td>
                                <td><strong><?= $total_nb_an ?></strong></td>
                                <td><strong><?= number_format($total_ca_an, 2) ?> €</strong></td>
                            </tr>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- BOX 3 DERNIERES COMMANDES -->
        <div class="dernieres-commandes-box">
            <h2>📦 3 dernières commandes</h2>
            
            <?php if(empty($dernieres_commandes)): ?>
                <div class="aucune-commande">
                    <p>Aucune commande pour le moment</p>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Client</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Statut</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($dernieres_commandes as $commande): ?>
                        <tr>
                            <td><strong>#<?= str_pad($commande['id'], 6, '0', STR_PAD_LEFT) ?></strong></td>
                            <td><?= htmlspecialchars($commande['nom']) ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($commande['date_commande'])) ?></td>
                            <td class="total-commande"><?= number_format($commande['total'], 2) ?> €</td>
                            <td>
                                <span class="statut-badge statut-<?= $commande['statut'] ?>">
                                    <?= $commande['statut'] ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
            
            <a href="admin_commandes.php" class="btn-voir-toutes">Voir toutes les commandes →</a>
        </div>

        <!-- MENU ADMIN -->
        <div class="menu-grid">
            <a href="admin_livres.php" class="menu-item">
                <h3>📖 Gestion des livres</h3>
                <p>Ajouter, modifier, supprimer des livres et gérer les stocks</p>
            </a>
            <a href="admin_commandes.php" class="menu-item">
                <h3>📦 Gestion des commandes</h3>
                <p>Voir et gérer les commandes clients</p>
            </a>
            <a href="admin_utilisateurs.php" class="menu-item">
                <h3>👥 Gestion des utilisateurs</h3>
                <p>Gérer les comptes clients</p>
            </a>
        </div>
    </div>
</body>
</html>
