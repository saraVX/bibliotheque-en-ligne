<?php
session_start();
require_once 'config.php';
require_once 'check_admin.php';
requireUser();

if(!isset($_GET['commande']) || !isset($_GET['methode'])) {
    header('Location: index.php');
    exit;
}

$commande_id = $_GET['commande'];
$methode = $_GET['methode'];
$user_id = $_SESSION['user_id'];

// Récupérer la commande
$commande = $db->prepare("
    SELECT c.*, u.nom, u.email 
    FROM commandes c
    JOIN utilisateurs u ON c.user_id = u.id
    WHERE c.id = ? AND c.user_id = ?
");
$commande->execute([$commande_id, $user_id]);
$commande = $commande->fetch();

if(!$commande) {
    header('Location: index.php');
    exit;
}

// Récupérer les détails de la commande
$details = $db->prepare("
    SELECT cd.*, l.titre 
    FROM commande_details cd
    JOIN livres l ON cd.livre_id = l.id
    WHERE cd.commande_id = ?
");
$details->execute([$commande_id]);
$articles = $details->fetchAll();

// Traitement du paiement
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $db->beginTransaction();
        
        // Simuler un paiement réussi
        $numero_transaction = 'TXN' . time() . rand(1000, 9999);
        
        // Mettre à jour la transaction
        $update = $db->prepare("
            UPDATE transactions 
            SET statut = 'confirme', transaction_id = ?, date_transaction = CURRENT_TIMESTAMP
            WHERE commande_id = ? AND user_id = ?
        ");
        $update->execute([$numero_transaction, $commande_id, $user_id]);
        
        // Mettre à jour le statut de la commande
        $update_commande = $db->prepare("
            UPDATE commandes 
            SET statut = 'confirmee' 
            WHERE id = ?
        ");
        $update_commande->execute([$commande_id]);
        
        // Ajouter au suivi
        $suivi = $db->prepare("
            INSERT INTO suivi_livraison (commande_id, statut, commentaire)
            VALUES (?, 'paiement_recu', 'Paiement confirmé, commande en cours de préparation')
        ");
        $suivi->execute([$commande_id]);
        
        $db->commit();
        
        $success = true;
        $message = "Paiement effectué avec succès ! Votre commande est confirmée.";
        
    } catch(Exception $e) {
        $db->rollBack();
        $erreur = "Erreur lors du paiement: " . $e->getMessage();
    }
}

// Récupérer le mode de livraison
$mode_livraison = $commande['mode_livraison'];

// Générer un numéro de suivi fictif
$numero_suivi = 'BIB' . str_pad($commande_id, 8, '0', STR_PAD_LEFT) . 'FR';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiement - Bibliothèque</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .payment-container {
            max-width: 600px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        
        .payment-card {
            background: white;
            border-radius: 20px;
            padding: 3rem;
            box-shadow: var(--shadow);
            animation: scaleIn 0.5s ease;
        }
        
        .payment-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .payment-header h1 {
            font-size: 2rem;
            font-weight: 300;
            color: var(--text);
        }
        
        .payment-header h1 span {
            color: var(--accent);
            font-weight: 700;
        }
        
        .order-summary {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .summary-item {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid #e9ecef;
        }
        
        .summary-item:last-child {
            border-bottom: none;
        }
        
        .total {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--success);
            margin-top: 1rem;
            text-align: right;
        }
        
        .payment-method {
            text-align: center;
            margin: 2rem 0;
            padding: 1rem;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 15px;
        }
        
        .payment-method img {
            max-width: 200px;
            margin: 1rem 0;
        }
        
        .card-form {
            margin: 2rem 0;
        }
        
        .card-input {
            position: relative;
        }
        
        .card-icons {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            display: flex;
            gap: 0.5rem;
        }
        
        .card-icon {
            width: 40px;
            height: 25px;
            background: #f8f9fa;
            border-radius: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            color: var(--text-light);
        }
        
        .expiry-cvv {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .btn-payer {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(135deg, var(--success) 0%, #229954 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.2rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            margin: 2rem 0;
        }
        
        .btn-payer:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40, 167, 69, 0.3);
        }
        
        .security-info {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 1rem;
            color: var(--text-light);
            font-size: 0.9rem;
        }
        
        .security-info span {
            display: flex;
            align-items: center;
            gap: 0.3rem;
        }
        
        .success-message {
            text-align: center;
        }
        
        .success-icon {
            font-size: 5rem;
            margin-bottom: 1rem;
            animation: scaleIn 0.5s ease;
        }
        
        .tracking-number {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 10px;
            margin: 2rem 0;
            font-size: 1.2rem;
        }
        
        .tracking-number code {
            background: var(--primary);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            font-size: 1.3rem;
        }
        
        .delivery-info {
            background: #e3f2fd;
            padding: 1.5rem;
            border-radius: 10px;
            margin: 2rem 0;
            text-align: left;
        }
        
        .delivery-info h3 {
            color: var(--primary);
            margin-bottom: 1rem;
        }
        
        .delivery-info p {
            margin: 0.5rem 0;
            color: var(--text);
        }
        
        .btn-retour {
            display: inline-block;
            padding: 1rem 2rem;
            background: var(--primary);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <div class="logo">
                <a href="index.php">📚 <span>Biblio</span>thèque</a>
            </div>
            <div class="nav-links">
                <a href="index.php">Accueil</a>
                <a href="mes_commandes.php">Mes commandes</a>
            </div>
        </div>
    </header>

    <div class="payment-container">
        <div class="payment-card">
            <?php if(isset($success)): ?>
                <!-- Page de succès -->
                <div class="success-message">
                    <div class="success-icon">✅</div>
                    <h1>Paiement réussi !</h1>
                    <p><?= $message ?></p>
                    
                    <div class="tracking-number">
                        <p>Numéro de suivi de votre colis :</p>
                        <code><?= $numero_suivi ?></code>
                    </div>
                    
                    <div class="delivery-info">
                        <h3>🚚 Suivi de livraison</h3>
                        <p><strong>Mode de livraison :</strong> <?= htmlspecialchars($mode_livraison) ?></p>
                        <p><strong>Date de livraison prévue :</strong> <?= date('d/m/Y', strtotime($commande['date_livraison_prevue'])) ?></p>
                        <p><strong>Adresse de livraison :</strong><br>
                        <?= nl2br(htmlspecialchars($commande['adresse'])) ?><br>
                        <?= htmlspecialchars($commande['code_postal']) ?> <?= htmlspecialchars($commande['ville']) ?></p>
                    </div>
                    
                    <div class="order-summary">
                        <h3 style="margin-bottom: 1rem;">Récapitulatif</h3>
                        <?php foreach($articles as $article): ?>
                        <div class="summary-item">
                            <span><?= htmlspecialchars($article['titre']) ?> x<?= $article['quantite'] ?></span>
                            <span><?= number_format($article['prix_unitaire'] * $article['quantite'], 2) ?> €</span>
                        </div>
                        <?php endforeach; ?>
                        <div class="summary-item">
                            <span>Livraison</span>
                            <span><?= number_format($commande['frais_livraison'], 2) ?> €</span>
                        </div>
                        <div class="total">
                            Total : <?= number_format($commande['total'], 2) ?> €
                        </div>
                    </div>
                    
                    <a href="index.php" class="btn-retour">Retour à l'accueil</a>
                    <a href="mes_commandes.php" class="btn-retour" style="background: var(--accent);">Suivre ma commande</a>
                </div>
                
            <?php elseif(isset($erreur)): ?>
                <!-- Page d'erreur -->
                <div class="success-message">
                    <div class="success-icon" style="color: var(--danger);">❌</div>
                    <h1>Erreur de paiement</h1>
                    <p><?= $erreur ?></p>
                    <a href="commander.php" class="btn-retour">Réessayer</a>
                </div>
                
            <?php else: ?>
                <!-- Formulaire de paiement -->
                <div class="payment-header">
                    <h1>💳 <span>Paiement</span> sécurisé</h1>
                    <p>Commande #<?= str_pad($commande_id, 6, '0', STR_PAD_LEFT) ?></p>
                </div>
                
                <div class="order-summary">
                    <h3 style="margin-bottom: 1rem;">Récapitulatif</h3>
                    <?php foreach($articles as $article): ?>
                    <div class="summary-item">
                        <span><?= htmlspecialchars($article['titre']) ?> x<?= $article['quantite'] ?></span>
                        <span><?= number_format($article['prix_unitaire'] * $article['quantite'], 2) ?> €</span>
                    </div>
                    <?php endforeach; ?>
                    <div class="summary-item">
                        <span>Livraison (<?= htmlspecialchars($mode_livraison) ?>)</span>
                        <span><?= number_format($commande['frais_livraison'], 2) ?> €</span>
                    </div>
                    <div class="total">
                        Total à payer : <?= number_format($commande['total'], 2) ?> €
                    </div>
                </div>
                
                <div class="payment-method">
                    <?php if($methode == 'cb'): ?>
                        <h3>💳 Paiement par carte bancaire</h3>
                        <p>Paiement sécurisé via notre partenaire bancaire</p>
                        
                        <form method="post" class="card-form">
                            <div class="form-group card-input">
                                <label>Numéro de carte</label>
                                <input type="text" placeholder="1234 5678 9012 3456" required>
                                <div class="card-icons">
                                    <span class="card-icon">VISA</span>
                                    <span class="card-icon">MC</span>
                                    <span class="card-icon">CB</span>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Nom sur la carte</label>
                                <input type="text" placeholder="JEAN DUPONT" required>
                            </div>
                            
                            <div class="expiry-cvv">
                                <div class="form-group">
                                    <label>Date d'expiration</label>
                                    <input type="text" placeholder="MM/AA" required>
                                </div>
                                <div class="form-group">
                                    <label>CVV</label>
                                    <input type="text" placeholder="123" required>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn-payer">Payer <?= number_format($commande['total'], 2) ?> €</button>
                        </form>
                        
                    <?php elseif($methode == 'paypal'): ?>
                        <h3>📱 Paiement PayPal</h3>
                        <p>Vous allez être redirigé vers PayPal</p>
                        <img src="https://www.paypalobjects.com/webstatic/mktg/logo/pp_cc_mark_37x23.jpg" alt="PayPal">
                        
                        <form method="post">
                            <button type="submit" class="btn-payer">Continuer sur PayPal</button>
                        </form>
                        
                    <?php elseif($methode == 'virement'): ?>
                        <h3>🏦 Virement bancaire</h3>
                        <p>Effectuez un virement sur notre compte :</p>
                        <div style="background: #f8f9fa; padding: 1rem; border-radius: 10px; text-align: left; margin: 1rem 0;">
                            <p><strong>Banque :</strong> Banque de la Bibliothèque</p>
                            <p><strong>IBAN :</strong> FR76 1234 5678 9012 3456 7890 123</p>
                            <p><strong>BIC :</strong> BIBLIOFRPP</p>
                            <p><strong>Référence :</strong> COMMANDE_<?= str_pad($commande_id, 6, '0', STR_PAD_LEFT) ?></p>
                        </div>
                        
                        <form method="post">
                            <button type="submit" class="btn-payer">J'ai effectué le virement</button>
                        </form>
                        
                    <?php else: ?>
                        <h3>💰 Paiement à la livraison</h3>
                        <p>Vous paierez à la réception de votre commande</p>
                        
                        <form method="post">
                            <button type="submit" class="btn-payer">Confirmer la commande</button>
                        </form>
                    <?php endif; ?>
                </div>
                
                <div class="security-info">
                    <span>🔒 Paiement sécurisé</span>
                    <span>🛡️ Données cryptées</span>
                    <span>⚡ 3D Secure</span>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
