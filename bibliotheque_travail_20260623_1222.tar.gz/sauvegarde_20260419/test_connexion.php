<?php
require_once 'config.php';

echo "<h2>Test de connexion</h2>";

// Voir tous les utilisateurs
$users = $db->query("SELECT id, nom, email, role FROM utilisateurs")->fetchAll();

echo "<h3>Utilisateurs dans la base :</h3>";
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>ID</th><th>Nom</th><th>Email</th><th>Rôle</th></tr>";
foreach($users as $user) {
    echo "<tr>";
    echo "<td>" . $user['id'] . "</td>";
    echo "<td>" . $user['nom'] . "</td>";
    echo "<td>" . $user['email'] . "</td>";
    echo "<td>" . $user['role'] . "</td>";
    echo "</tr>";
}
echo "</table>";

// Tester un mot de passe admin
$admin = $db->prepare("SELECT * FROM utilisateurs WHERE email = ?");
$admin->execute(['admin@bibliotheque.com']);
$admin_user = $admin->fetch();

if($admin_user) {
    echo "<h3>Test admin :</h3>";
    echo "Email: " . $admin_user['email'] . "<br>";
    echo "Hash mot de passe: " . $admin_user['password'] . "<br>";
    
    $test_password = 'admin123';
    if(password_verify($test_password, $admin_user['password'])) {
        echo "✅ Mot de passe 'admin123' VALIDE !<br>";
    } else {
        echo "❌ Mot de passe 'admin123' INVALIDE !<br>";
    }
} else {
    echo "<h3>❌ Admin non trouvé !</h3>";
}
?>
