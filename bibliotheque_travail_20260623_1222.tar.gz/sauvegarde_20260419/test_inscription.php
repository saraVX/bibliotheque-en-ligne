<?php
require_once 'config.php';

echo "<h2>Test d'inscription</h2>";

// Tester l'insertion
$nom = "Test User";
$email = "test_" . time() . "@test.com";
$password = password_hash("test123", PASSWORD_DEFAULT);

$stmt = $db->prepare("INSERT INTO utilisateurs (nom, email, password, role) VALUES (?, ?, ?, 'user')");

if($stmt->execute([$nom, $email, $password])) {
    echo "✅ Inscription test réussie !<br>";
    echo "Email: $email<br>";
    echo "Mot de passe: test123<br>";
} else {
    echo "❌ Erreur d'inscription<br>";
}

// Afficher tous les utilisateurs
echo "<h3>Tous les utilisateurs :</h3>";
$users = $db->query("SELECT id, nom, email, role FROM utilisateurs")->fetchAll();
echo "<ul>";
foreach($users as $user) {
    echo "<li>" . $user['nom'] . " - " . $user['email'] . " - Rôle: " . $user['role'] . "</li>";
}
echo "</ul>";
?>
